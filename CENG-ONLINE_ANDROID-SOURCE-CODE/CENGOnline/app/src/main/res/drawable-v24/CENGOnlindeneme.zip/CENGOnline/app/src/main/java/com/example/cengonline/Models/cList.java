package com.example.cengonline.Models;

public class cList {
    String cKey;

    public cList(String cKey) {
        this.cKey = cKey;
    }
    public cList() {

    }

    public String getcKey() {
        return cKey;
    }

    public void setcKey(String cKey) {
        this.cKey = cKey;
    }
}
